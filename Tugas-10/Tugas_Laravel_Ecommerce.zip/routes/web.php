<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;

/*
|--------------------------------------------------------------------------
| Web Routes - E-Commerce
|--------------------------------------------------------------------------
| TUGAS 2: Route dasar untuk website e-commerce
*/

// Halaman utama
Route::get('/', function () {
    return view('welcome');
})->name('home');

// Daftar produk
Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{id}', [ProductController::class, 'show'])->name('products.show');

// Keranjang belanja
Route::get('/cart', [OrderController::class, 'showCart'])->name('cart.index');
Route::post('/cart/add/{id}', [OrderController::class, 'addToCart'])->name('cart.add');
Route::delete('/cart/remove/{id}', [OrderController::class, 'removeFromCart'])->name('cart.remove');

// Checkout
Route::get('/checkout', [OrderController::class, 'showCheckout'])->name('checkout.index');
Route::post('/checkout', [OrderController::class, 'processCheckout'])->name('checkout.process');
