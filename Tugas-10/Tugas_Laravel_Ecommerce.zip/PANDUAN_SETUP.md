# Panduan Setup Proyek Laravel E-Commerce

## 1. Buat Proyek Laravel Baru
Jalankan di terminal (pastikan Composer & PHP sudah terinstall):

```bash
composer create-project laravel/laravel ecommerce-laravel
cd ecommerce-laravel
```

Atau kalau sudah punya Laravel installer:
```bash
laravel new ecommerce-laravel
cd ecommerce-laravel
```

## 2. Konfigurasi Database
Buka file `.env` di root project, edit bagian ini sesuai database MySQL kamu
(bisa pakai database `ecommerce_db` yang sudah dibuat sebelumnya, atau buat baru):

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ecommerce_db
DB_USERNAME=root
DB_PASSWORD=
```

## 3. Copy File-File dari Paket Ini
Copy file-file berikut ke lokasi yang sama di project Laravel kamu (menimpa file default):

| File di paket ini              | Taruh di                                      |
|---------------------------------|------------------------------------------------|
| routes/web.php                  | routes/web.php                                  |
| app/Models/Product.php          | app/Models/Product.php                          |
| app/Models/Order.php            | app/Models/Order.php                            |
| app/Http/Controllers/ProductController.php | app/Http/Controllers/ProductController.php |
| app/Http/Controllers/OrderController.php   | app/Http/Controllers/OrderController.php   |
| database/migrations/xxxx_create_products_table.php | database/migrations/ (buat file baru) |
| database/migrations/xxxx_create_orders_table.php   | database/migrations/ (buat file baru) |

## 4. Jalankan Migration
Ini akan otomatis membuat tabel `products` dan `orders` di database:

```bash
php artisan migrate
```

## 5. Jalankan Server Laravel
```bash
php artisan serve
```

Buka browser ke `http://127.0.0.1:8000` lalu coba akses:
- `/` — halaman utama
- `/products` — daftar produk
- `/cart` — halaman keranjang
- `/checkout` — halaman checkout

## Struktur Route yang Dibuat
- `GET  /`             → halaman utama (welcome/home)
- `GET  /products`     → tampilkan semua produk
- `GET  /cart`         → tampilkan isi keranjang
- `POST /cart/add/{id}`→ tambah produk ke keranjang
- `GET  /checkout`     → halaman checkout
- `POST /checkout`     → proses checkout (simpan order)

## Catatan
- Model `Product` dan `Order` sudah termasuk `$fillable` supaya bisa langsung dipakai untuk mass-assignment (create/update).
- Controller `ProductController` dan `OrderController` sudah berisi method dasar (index, store, dll) sebagai starting point — nanti tinggal dikembangin sesuai kebutuhan cart/checkout kamu.
- Kalau kamu mau pakai Blade view, buat folder `resources/views/products/index.blade.php` dan `resources/views/cart/index.blade.php` — bisa styling pakai Tailwind bawaan Laravel Breeze/Jetstream kalau mau lebih rapi.
