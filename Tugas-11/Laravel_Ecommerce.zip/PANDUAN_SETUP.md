# Panduan Setup Proyek Laravel E-Commerce

## 1. Buat Proyek Laravel Baru
Jalankan di terminal (pastikan Composer & PHP sudah terinstall):

```bash
composer create-project laravel/laravel ecommerce-laravel
cd ecommerce-laravel
```

Atau kalau sudah punya Laravel installer:
```bash
laravel new ecommerce-laravel
cd ecommerce-laravel
```

## 2. Konfigurasi Database
Buka file `.env` di root project, edit bagian ini sesuai database MySQL kamu
(bisa pakai database `ecommerce_db` yang sudah dibuat sebelumnya, atau buat baru):

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ecommerce_db
DB_USERNAME=root
DB_PASSWORD=
```

## 3. Copy File-File dari Paket Ini
Copy file-file berikut ke lokasi yang sama di project Laravel kamu (menimpa file default):

| File di paket ini              | Taruh di                                      |
|---------------------------------|------------------------------------------------|
| routes/web.php                  | routes/web.php                                  |
| app/Models/Product.php          | app/Models/Product.php                          |
| app/Models/Order.php            | app/Models/Order.php                            |
| app/Http/Controllers/ProductController.php | app/Http/Controllers/ProductController.php |
| app/Http/Controllers/OrderController.php   | app/Http/Controllers/OrderController.php   |
| app/Http/Controllers/PageController.php    | app/Http/Controllers/PageController.php    |
| database/migrations/xxxx_create_products_table.php | database/migrations/ (buat file baru) |
| database/migrations/xxxx_create_orders_table.php   | database/migrations/ (buat file baru) |

## 4. Jalankan Migration
Ini akan otomatis membuat tabel `products` dan `orders` di database:

```bash
php artisan migrate
```

## 5. Jalankan Server Laravel
```bash
php artisan serve
```

Buka browser ke `http://127.0.0.1:8000` lalu coba akses:
- `/` — halaman utama
- `/products` — daftar produk
- `/cart` — halaman keranjang
- `/checkout` — halaman checkout

## Struktur Route yang Dibuat
- `GET  /`               → halaman utama (PageController@home)
- `GET  /about`           → halaman tentang kami
- `GET  /contact`         → halaman kontak
- `POST /contact`         → kirim pesan dari form kontak
- `GET  /page/{slug}`     → halaman generik lain (about, terms, dll)
- `GET  /products`        → tampilkan semua produk
- `GET  /products/{id}`   → detail satu produk
- `POST /products`        → tambah produk baru
- `PUT  /products/{id}`   → update produk
- `DELETE /products/{id}` → hapus produk
- `GET  /cart`            → tampilkan isi keranjang
- `POST /cart/add/{id}`   → tambah produk ke keranjang
- `DELETE /cart/remove/{id}` → hapus produk dari keranjang
- `GET  /checkout`        → halaman checkout
- `POST /checkout`        → proses checkout (simpan order)

## Controller yang Dibuat
- **`ProductController`** — mengelola produk (index, show, store, update, destroy)
- **`OrderController`** — mengelola keranjang & checkout
- **`PageController`** — mengelola halaman statis (home, about, contact, dan halaman generik lewat slug)

## Catatan
- Model `Product` dan `Order` sudah termasuk `$fillable` supaya bisa langsung dipakai untuk mass-assignment (create/update).
- Semua controller sudah berisi method dasar sebagai starting point — tinggal dikembangin sesuai kebutuhan.
- Kalau mau pakai Blade view, buat folder-folder ini:
  - `resources/views/pages/home.blade.php`, `about.blade.php`, `contact.blade.php`
  - `resources/views/products/index.blade.php`, `show.blade.php`
  - `resources/views/cart/index.blade.php`
  - `resources/views/checkout/index.blade.php`
  Bisa styling pakai Tailwind bawaan Laravel Breeze/Jetstream kalau mau lebih rapi.
